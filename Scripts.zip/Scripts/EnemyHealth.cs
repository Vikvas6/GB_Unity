﻿using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    [SerializeField] private int _health = 1;

    public void RemoveHealth(int health)
    {
        _health -= health;

        if (_health <= 0)
        {
            Destroy(gameObject);
        }
    }
}
