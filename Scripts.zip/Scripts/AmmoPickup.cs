﻿using UnityEngine;

public class AmmoPickup : MonoBehaviour
{
    [SerializeField] private int _ammo = 15;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            var player = other.gameObject.GetComponent<MainCharacterAmmo>();
            player.AddAmmo(_ammo);
            Destroy(gameObject);
        }

    }
}
