﻿using System;
using UnityEngine;


public class EnemySpawnPoint : MonoBehaviour
{
    [SerializeField] private GameObject _spawnPoint;


    private void OnDestroy()
    {
        try
        {
            _spawnPoint.GetComponent<SpawnPoint>().ActivateSpawner();
        }
        catch (Exception)
        {
            //При остановке игры точка спавна может быть удалена раньше врага
        }
    }

    public void SetSpawnPoint(GameObject spawnPoint)
    {
        _spawnPoint = spawnPoint;
    }

    public GameObject GetSpawnPoint()
    {
        return _spawnPoint;
    }
}
