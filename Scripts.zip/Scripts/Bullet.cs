﻿using UnityEngine;


public class Bullet : MonoBehaviour
{
    [SerializeField] private float _speed = 15;
    [SerializeField] private float _lifeTime = 2.0f;
    [SerializeField] private int _damage = 1;

    private Rigidbody _rigidbody;
    private bool _hit = false;

    private void Start()
    {
        Destroy(gameObject, _lifeTime);

        _rigidbody = GetComponent<Rigidbody>();
        var impulse = transform.up * _rigidbody.mass * _speed;
        _rigidbody.AddForce(impulse, ForceMode.Impulse);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Enemy") && !_hit)
        {
            _hit = true;
            var enemy = other.GetComponent<EnemyHealth>();
            enemy.RemoveHealth(_damage);
            Destroy(gameObject);
        }
    }
}
