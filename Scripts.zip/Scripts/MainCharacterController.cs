﻿using UnityEngine;

public class MainCharacterController : MonoBehaviour
{

    [SerializeField] private float _speed = 7;
    [SerializeField] private float _rotateSpeed = 100;
    [SerializeField] private float _jumpForce = 5.0f;

    private Rigidbody _rigidBody;
    private Vector3 _jumpVector;
    private bool _isGrounded;

    private void Start()
    {
        _rigidBody = GetComponent<Rigidbody>();
        _jumpVector = new Vector3(0.0f, 1.0f, 0.0f);
    }

    private void OnCollisionStay(Collision collision)
    {
        _isGrounded = true;
    }
    // Update is called once per frame
    void Update()
    {
        float vectorX = Input.GetAxis("Horizontal");
        float vectorZ = Input.GetAxis("Vertical");

        transform.position += transform.forward * vectorZ * _speed * Time.deltaTime;
        transform.Rotate(0, vectorX * _rotateSpeed * Time.deltaTime, 0);

        if (Input.GetKeyDown(KeyCode.Space) && _isGrounded)
        {
            _rigidBody.AddForce(_jumpVector * _jumpForce, ForceMode.Impulse);
            _isGrounded = false;
        }
    }
}
