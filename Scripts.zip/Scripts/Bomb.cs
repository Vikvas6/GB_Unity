﻿using UnityEngine;

public class Bomb : MonoBehaviour
{
    [SerializeField] private int _damage = 2;
    [SerializeField] private float _lifeTime = 8.0f;

    private void Start()
    {
        Destroy(gameObject, _lifeTime);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Enemy"))
        {
            var enemy = other.GetComponent<EnemyHealth>();
            enemy.RemoveHealth(_damage);
            Destroy(gameObject);
        }
    }
}
