﻿using UnityEngine;

public class MainCharacterHealth : MonoBehaviour
{
    [SerializeField] private int _health = 2;

    public void AddHealth(int health)
    {
        _health += health;
    }
}
