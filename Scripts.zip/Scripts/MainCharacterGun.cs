﻿using UnityEngine;


public class MainCharacterGun : MonoBehaviour
{
    [SerializeField] private GameObject _bullet;
    [SerializeField] private Transform _bulletSpawnPosition;
    [SerializeField] private int _ammoCost = 1;
    [SerializeField] private int _reloadTime = 1;

    private MainCharacterAmmo _playerAmmo;

    private bool _isReloading = false;


    private void Start()
    {
        _playerAmmo = gameObject.GetComponent<MainCharacterAmmo>();
    }
    private void Update()
    {
        if (Input.GetButtonDown("Fire1") && _playerAmmo.GetAmmo() >= _ammoCost && _isReloading == false)
        {
            _playerAmmo.RemoveAmmo(_ammoCost);
            _isReloading = true;
            Invoke("Reload", _reloadTime);
            Instantiate(_bullet, _bulletSpawnPosition.position, _bulletSpawnPosition.rotation);
        }
    }

    private void Reload()
    {
        _isReloading = false;
    }
}
