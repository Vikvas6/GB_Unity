﻿using UnityEngine;


public class SpawnPoint : MonoBehaviour
{
    [SerializeField] private GameObject _enemyPrefab;
    [SerializeField] private float _spawnTime = 5;
    [SerializeField] private bool _activeSpawner;

    public void Start()
    {
        ActivateSpawner();
    }

    public bool IsActiveSpawner()
    {
        return _activeSpawner;
    }

    public void ActivateSpawner()
    {
        _activeSpawner = true;
        Invoke(nameof(Spawn), _spawnTime);
    }

    public void DeactivateSpawner()
    {
        _activeSpawner = false;
    }

    public void Spawn()
    {
        GameObject enemy = Instantiate(_enemyPrefab, gameObject.transform.position, gameObject.transform.rotation);
        DeactivateSpawner();
        enemy.GetComponent<EnemySpawnPoint>().SetSpawnPoint(gameObject);
    }
}
