﻿using UnityEngine;


public class MainCharacterBomb : MonoBehaviour
{
    [SerializeField] private GameObject _bomb;
    [SerializeField] private Transform _bombSpawnPosition;
    [SerializeField] private int _ammoCost = 2;
    [SerializeField] private int _reloadTime = 5;

    private MainCharacterAmmo _playerAmmo;
    private bool _isReloading = false;

    private void Start()
    {

        _playerAmmo = gameObject.GetComponent<MainCharacterAmmo>();
    }
    private void Update()
    {
        if (Input.GetButtonDown("Fire2") && _playerAmmo.GetAmmo() >= _ammoCost && _isReloading == false)
        {
            _playerAmmo.RemoveAmmo(_ammoCost);
            _isReloading = true;
            Invoke("Reload", _reloadTime);
            Instantiate(_bomb, _bombSpawnPosition.position, _bombSpawnPosition.rotation);
        }
    }

    private void Reload()
    {
        _isReloading = false;
    }
}
