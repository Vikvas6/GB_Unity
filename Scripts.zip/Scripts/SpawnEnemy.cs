﻿using System.Collections.Generic;
using UnityEngine;


public class SpawnEnemy : MonoBehaviour
{
    [SerializeField] private GameObject[] _enemies;
    [SerializeField] private Transform[] _spawnPoints;
    [SerializeField] private float _spawnTime = 5;

    private List<GameObject> sp_Enemies = new List<GameObject>();
    private float _timer = 0.0f;
    private bool[] _hasSpawned;

    private void Start()
    {
        InvokeRepeating(nameof(Spawn), 0.0f, _spawnTime);

        _hasSpawned = new bool[_spawnPoints.Length];
        for (int i = 0; i < _hasSpawned.Length; i++)
        {
            _hasSpawned[i] = false;
        }
    }

    private void Spawn()
    {
        for (int i = 0; i < _spawnPoints.Length; i++)
        {
            if (_hasSpawned[i] == false) break;
            if (sp_Enemies.Count >= _spawnPoints.Length) return;
            else break;
        }

        int num = Random.Range(0, _enemies.Length);
        GameObject go = _enemies[num];

        num = Random.Range(0, _spawnPoints.Length);
        Transform tr = _spawnPoints[num];

        _hasSpawned[num] = true;

        sp_Enemies.Add(Instantiate(go, tr.position, tr.rotation));
    }
}
