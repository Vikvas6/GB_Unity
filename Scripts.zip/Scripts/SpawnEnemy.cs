﻿using UnityEngine;

public class SpawnEnemy : MonoBehaviour
{
    [SerializeField] private GameObject _enemy;
    [SerializeField] private float _spawnTime = 5;
    [SerializeField] private bool _active = false;

    private float _timer = 0.0f;

    private void Start()
    {
        Spawn();
    }

    // Update is called once per frame
    private void Update()
    {
        if (_active)
        {
            _timer += Time.deltaTime;
            if (_timer > _spawnTime)
            {
                Spawn();
            }
        }
    }

    private void Spawn()
    {
        Instantiate(_enemy, gameObject.transform.position, gameObject.transform.rotation);
        _enemy.GetComponent<EnemyController>().SetSpawnPoint(gameObject);
        _timer -= 0.0f;
        _active = false;
    }

    public void ActivateSpawner()
    {
        _active = true;
    }
}
