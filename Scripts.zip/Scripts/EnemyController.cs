﻿using UnityEngine;

public class EnemyController : MonoBehaviour
{
    [SerializeField] private GameObject _spawnPoint;

    public void OnDeath()
    {
        _spawnPoint.GetComponent<SpawnEnemy>().ActivateSpawner();
    }

    public void SetSpawnPoint(GameObject spawnPoint)
    {
        _spawnPoint = spawnPoint;
    }

    private void OnDestroy()
    {
        _spawnPoint.GetComponent<SpawnEnemy>().ActivateSpawner();
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            Vector3 relativePos = other.gameObject.transform.position - transform.position;
            Vector3 newDir = Vector3.RotateTowards(transform.forward, relativePos, 2 * Time.deltaTime, 10F);
            transform.rotation = Quaternion.LookRotation(newDir);
        }
    }
}
