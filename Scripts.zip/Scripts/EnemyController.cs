﻿using UnityEngine;


public class EnemyController : MonoBehaviour
{
    [SerializeField] private LayerMask _mask;
    [SerializeField] private float _visionDistance = 10.0f;
    [SerializeField] private float _speed = 2.0f;
    [SerializeField] private float _moveDelay = 2.0f;

    private Transform _player;
    private GameObject _spawner;
    private Vector3 _currentPositionWithOffset;
    private Vector3 _playerRelativePositionWithOffset;
    private Vector3 _spanwerRelativePosition;
    private float _startOffset = 0.25f;
    private bool _moveToPlayer = false;

    private void Start()
    {
        _player = GameObject.FindGameObjectWithTag("Player").transform;
        _spawner = gameObject.GetComponent<EnemySpawnPoint>().GetSpawnPoint();
    }

    private void FixedUpdate()
    {
        Color color = Color.red;

        RaycastHit hit;
        _currentPositionWithOffset = CalculateOffset(transform.position);
        _playerRelativePositionWithOffset = CalculateOffset(_player.position - _currentPositionWithOffset);
        _spanwerRelativePosition = _spawner.transform.position - transform.position;

        var rayCast = Physics.Raycast(_currentPositionWithOffset, _playerRelativePositionWithOffset, out hit, _visionDistance, _mask);

        if (rayCast)
        {
            if (hit.collider.gameObject.CompareTag("Player"))
            {
                color = Color.green;
                SetMoveToPlayer(true);
                CancelInvoke(nameof(CancelMoveToPlayer));
            }
            else
            {
                if (_moveToPlayer)
                {
                    Invoke(nameof(CancelMoveToPlayer), _moveDelay);
                }
            }
        }
        else
        {
            if (_moveToPlayer)
            {
                Invoke(nameof(CancelMoveToPlayer), _moveDelay);
            }
        }

        Move();
    }

    private Vector3 CalculateOffset (Vector3 position)
    {
        position.y += _startOffset;
        return position;
    }

    private void SetMoveToPlayer(bool moveToPlayer)
    {
        _moveToPlayer = moveToPlayer;
    }

    private void CancelMoveToPlayer()
    {
        SetMoveToPlayer(false);
    }

    private void Move()
    {
        
        if (_moveToPlayer)
        {
            MoveTo(_playerRelativePositionWithOffset);
        }
        else
        {
            if (Vector3.SqrMagnitude(_spanwerRelativePosition) > 5.0f)
            {
                MoveTo(_spanwerRelativePosition);
            }
        }
    }

    private void MoveTo(Vector3 position)
    {
        Vector3 newDir = Vector3.RotateTowards(transform.forward, position, 2 * Time.deltaTime, 10F);
        transform.rotation = Quaternion.LookRotation(newDir);
        transform.position += transform.forward * _speed * Time.deltaTime;
    }
}
