﻿using UnityEngine;

public class BombSpawner : MonoBehaviour
{
    [SerializeField] private GameObject _bomb;
    [SerializeField] private Transform _bombSpawnPosition;

    private MainCharacterAmmo _playerAmmo;

    private void Start()
    {

        _playerAmmo = gameObject.GetComponent<MainCharacterAmmo>();
    }
    private void Update()
    {
        if (Input.GetButtonDown("Fire1") && _playerAmmo.GetAmmo() > 0)
        {
            _playerAmmo.RemoveAmmo();
            Instantiate(_bomb, _bombSpawnPosition.position, _bombSpawnPosition.rotation);
        }
    }
}
