﻿using UnityEngine;

public class MainCharacterAmmo : MonoBehaviour
{
    [SerializeField] private int _ammo = 15;

    public void AddAmmo(int ammo)
    {
        _ammo += ammo;
    }

    public void RemoveAmmo()
    {
        RemoveAmmo(1);
    }

    public void RemoveAmmo(int ammo)
    {
        _ammo -= ammo;
    }

    public int GetAmmo()
    {
        return _ammo;
    }
}
